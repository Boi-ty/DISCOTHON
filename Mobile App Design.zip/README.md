
  # Mobile App Design

  This is a code bundle for Mobile App Design. The original project is available at https://www.figma.com/design/kXxPGFN3Md87TK1eTMUbfs/Mobile-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  